package com.reyfree.transformers.item;

import com.reyfree.transformers.registry.ModEntities;
import com.reyfree.transformers.entity.TransformerEntity;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class TransformerCoreItem extends Item {
    private final boolean police;

    public TransformerCoreItem(boolean police, Properties properties) {
        super(properties);
        this.police = police;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            TransformerEntity transformer = ModEntities.TRANSFORMER.get().create(level);
            if (transformer != null) {
                transformer.setPolice(police);
                transformer.moveTo(player.getX() + player.getLookAngle().x * 2.0D,
                        player.getY(), player.getZ() + player.getLookAngle().z * 2.0D,
                        player.getYRot(), 0.0F);
                level.addFreshEntity(transformer);
                if (!player.getAbilities().instabuild) stack.shrink(1);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
