package com.reyfree.transformers.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.reyfree.transformers.TransformersMod;
import com.reyfree.transformers.entity.TransformerEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Layered mechanical Transformer model with a shaped face, optical lenses and faceted tires for Minecraft 1.18.2. */
public class TransformerModel<T extends TransformerEntity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(TransformersMod.MODID, "transformer"), "main");

    private final ModelPart robot, vehicle, head, leftArm, rightArm, leftLeg, rightLeg;
    private float robotScale = 1.0F, vehicleScale = 0.0F;
    private float robotFold = 0.0F;

    public TransformerModel(ModelPart root) {
        robot = root.getChild("robot");
        vehicle = root.getChild("vehicle");
        head = robot.getChild("head");
        leftArm = robot.getChild("left_arm");
        rightArm = robot.getChild("right_arm");
        leftLeg = robot.getChild("left_leg");
        rightLeg = robot.getChild("right_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition robot = root.addOrReplaceChild("robot", CubeListBuilder.create(), PartPose.ZERO);

        // Torso: layered chest, windshield-like chest plate, abdomen and back pack.
        robot.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-5, -7, -3, 10, 12, 6)
                .texOffs(64, 0).addBox(-4.5F, -6, -4, 9, 7, 1)
                .texOffs(64, 18).addBox(-3.5F, 1, -3.8F, 7, 4, 1)
                .texOffs(0, 40).addBox(-4, -5, 3, 8, 9, 2)
                .texOffs(84, 40).addBox(-5.5F, -6, -3.5F, 2, 5, 7)
                .texOffs(84, 40).addBox(3.5F, -6, -3.5F, 2, 5, 7)
                // Slanted chest armor and segmented lower chest.
                .texOffs(64, 64).addBox(-4.7F, -6.2F, -4.65F, 4.2F, 4.0F, 1.0F)
                .texOffs(64, 64).addBox(0.5F, -6.2F, -4.65F, 4.2F, 4.0F, 1.0F)
                .texOffs(88, 64).addBox(-2.6F, -2.0F, -4.55F, 5.2F, 2.8F, 1.0F)
                .texOffs(96, 72).addBox(-3.5F, 2.3F, -3.9F, 7.0F, 2.0F, 1.2F), PartPose.ZERO);

        // Small angular chest plates, exposed pistons and a recessed energy core.
        robot.addOrReplaceChild("chest_core", CubeListBuilder.create()
                .texOffs(100, 64).addBox(-1.45F, -5.1F, -4.95F, 2.9F, 3.0F, 0.65F)
                .texOffs(104, 72).addBox(-0.8F, -4.5F, -5.05F, 1.6F, 1.7F, 0.25F), PartPose.ZERO);
        robot.addOrReplaceChild("chest_vent_left", CubeListBuilder.create()
                .texOffs(112, 64).addBox(-4.1F, -1.2F, -4.25F, 2.0F, 0.45F, 0.35F)
                .texOffs(112, 66).addBox(-4.1F, -0.3F, -4.25F, 2.0F, 0.35F, 0.35F), PartPose.ZERO);
        robot.addOrReplaceChild("chest_vent_right", CubeListBuilder.create()
                .texOffs(112, 64).addBox(2.1F, -1.2F, -4.25F, 2.0F, 0.45F, 0.35F)
                .texOffs(112, 66).addBox(2.1F, -0.3F, -4.25F, 2.0F, 0.35F, 0.35F), PartPose.ZERO);

        // Helmet and face inspired by the angular mechanical language of the 2007 film:
        // narrow optics, a real brow, cheek armor, nose bridge, mouth grille and jaw plate.
        PartDefinition head = robot.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 64).addBox(-3.25F, -16.2F, -3.35F, 6.5F, 6.8F, 6.7F)
                .texOffs(56, 64).addBox(-3.0F, -17.0F, -2.7F, 6.0F, 1.7F, 5.4F)
                .texOffs(100, 80).addBox(-3.3F, -14.6F, -3.95F, 6.6F, 1.05F, 1.0F)
                .texOffs(64, 80).addBox(-2.55F, -10.8F, -3.95F, 5.1F, 1.35F, 1.05F), PartPose.ZERO);

        // Deep eye sockets and luminous narrow optics. The lens color is supplied by each variant texture.
        head.addOrReplaceChild("eye_socket_left", CubeListBuilder.create()
                .texOffs(104, 80).addBox(-2.35F, -13.45F, -4.18F, 1.9F, 1.0F, 0.45F), PartPose.ZERO);
        head.addOrReplaceChild("eye_socket_right", CubeListBuilder.create()
                .texOffs(104, 80).addBox(0.45F, -13.45F, -4.18F, 1.9F, 1.0F, 0.45F), PartPose.ZERO);
        head.addOrReplaceChild("optic_left", CubeListBuilder.create()
                .texOffs(116, 0).addBox(-2.05F, -13.20F, -4.43F, 1.35F, 0.48F, 0.18F), PartPose.ZERO);
        head.addOrReplaceChild("optic_right", CubeListBuilder.create()
                .texOffs(120, 0).addBox(0.70F, -13.20F, -4.43F, 1.35F, 0.48F, 0.18F), PartPose.ZERO);

        // Nose bridge, separate cheek guards, mouth grille and chin armor prevent a blank cube face.
        head.addOrReplaceChild("nose_bridge", CubeListBuilder.create()
                .texOffs(96, 84).addBox(-0.55F, -13.15F, -4.35F, 1.1F, 1.75F, 0.8F), PartPose.ZERO);
        head.addOrReplaceChild("cheek_left", CubeListBuilder.create()
                .texOffs(80, 84).addBox(-3.15F, -12.5F, -3.75F, 1.25F, 2.4F, 1.1F),
                PartPose.offsetAndRotation(-0.05F, 0.0F, 0.0F, 0.0F, 0.0F, -0.13F));
        head.addOrReplaceChild("cheek_right", CubeListBuilder.create()
                .texOffs(80, 84).addBox(1.9F, -12.5F, -3.75F, 1.25F, 2.4F, 1.1F),
                PartPose.offsetAndRotation(0.05F, 0.0F, 0.0F, 0.0F, 0.0F, 0.13F));
        head.addOrReplaceChild("mouth_grille", CubeListBuilder.create()
                .texOffs(116, 4).addBox(-1.55F, -10.25F, -4.52F, 3.1F, 0.55F, 0.18F), PartPose.ZERO);
        head.addOrReplaceChild("chin_guard", CubeListBuilder.create()
                .texOffs(88, 88).addBox(-1.55F, -9.75F, -3.9F, 3.1F, 1.15F, 1.15F), PartPose.ZERO);

        // Side audio housings and swept-back helmet fins.
        head.addOrReplaceChild("left_audio", CubeListBuilder.create()
                .texOffs(104, 88).addBox(-3.85F, -13.6F, -1.1F, 0.9F, 2.1F, 2.2F), PartPose.ZERO);
        head.addOrReplaceChild("right_audio", CubeListBuilder.create()
                .texOffs(104, 88).addBox(2.95F, -13.6F, -1.1F, 0.9F, 2.1F, 2.2F), PartPose.ZERO);
        head.addOrReplaceChild("left_helmet_fin", CubeListBuilder.create()
                .texOffs(112, 88).addBox(-0.4F, -2.0F, -0.55F, 0.8F, 2.5F, 1.1F),
                PartPose.offsetAndRotation(-2.7F, -15.8F, -0.25F, 0.0F, 0.0F, -0.28F));
        head.addOrReplaceChild("right_helmet_fin", CubeListBuilder.create()
                .texOffs(112, 88).addBox(-0.4F, -2.0F, -0.55F, 0.8F, 2.5F, 1.1F),
                PartPose.offsetAndRotation(2.7F, -15.8F, -0.25F, 0.0F, 0.0F, 0.28F));

        // Shoulder armour, upper arms, elbow joints, forearm guards and hands.
        robot.addOrReplaceChild("left_arm", CubeListBuilder.create()
                .texOffs(0, 104).addBox(5, -7, -3.5F, 6, 6, 7)
                .texOffs(52, 96).addBox(6, -2, -2.5F, 4, 7, 5)
                .texOffs(88, 64).addBox(5.5F, 3, -3, 5, 6, 6)
                .texOffs(88, 88).addBox(6, 8, -2.5F, 4, 3, 5)
                .texOffs(92, 96).addBox(5.1F, -7.8F, -3.2F, 5.8F, 1.4F, 6.4F)
                .texOffs(104, 96).addBox(6.5F, 4.0F, -3.2F, 3.2F, 1.0F, 6.4F)
                .texOffs(112, 96).addBox(7.0F, 10.5F, -1.9F, 2.0F, 1.2F, 3.8F), PartPose.ZERO);
        robot.addOrReplaceChild("right_arm", CubeListBuilder.create()
                .texOffs(0, 104).addBox(-11, -7, -3.5F, 6, 6, 7)
                .texOffs(52, 96).addBox(-10, -2, -2.5F, 4, 7, 5)
                .texOffs(88, 64).addBox(-10.5F, 3, -3, 5, 6, 6)
                .texOffs(88, 88).addBox(-10, 8, -2.5F, 4, 3, 5)
                .texOffs(92, 96).addBox(-10.9F, -7.8F, -3.2F, 5.8F, 1.4F, 6.4F)
                .texOffs(104, 96).addBox(-9.7F, 4.0F, -3.2F, 3.2F, 1.0F, 6.4F)
                .texOffs(112, 96).addBox(-9.0F, 10.5F, -1.9F, 2.0F, 1.2F, 3.8F), PartPose.ZERO);

        // Large thigh plates, shins, feet and front toe armour.
        robot.addOrReplaceChild("left_leg", CubeListBuilder.create()
                .texOffs(0, 0).addBox(1, 4, -3, 5, 8, 6)
                .texOffs(44, 40).addBox(1.5F, 10, -3.5F, 5, 7, 7)
                .texOffs(44, 104).addBox(0.5F, 15, -5, 6, 3, 8)
                .texOffs(64, 104).addBox(1.3F, 8.0F, -4.0F, 4.5F, 3.0F, 1.2F)
                .texOffs(80, 104).addBox(2.0F, 12.0F, -4.4F, 3.5F, 2.7F, 1.1F)
                .texOffs(96, 104).addBox(1.8F, 16.2F, -5.2F, 4.0F, 1.0F, 1.0F), PartPose.ZERO);
        robot.addOrReplaceChild("right_leg", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-6, 4, -3, 5, 8, 6)
                .texOffs(44, 40).addBox(-6.5F, 10, -3.5F, 5, 7, 7)
                .texOffs(44, 104).addBox(-6.5F, 15, -5, 6, 3, 8)
                .texOffs(64, 104).addBox(-5.8F, 8.0F, -4.0F, 4.5F, 3.0F, 1.2F)
                .texOffs(80, 104).addBox(-5.5F, 12.0F, -4.4F, 3.5F, 2.7F, 1.1F)
                .texOffs(96, 104).addBox(-5.8F, 16.2F, -5.2F, 4.0F, 1.0F, 1.0F), PartPose.ZERO);

        // Wheels mounted high on the shoulders and small side armour panels.
        addWheel(robot, "left_shoulder_wheel", 9, -5, 0);
        addWheel(robot, "right_shoulder_wheel", -9, -5, 0);
        robot.addOrReplaceChild("left_back_panel", CubeListBuilder.create().texOffs(96, 24).addBox(5, -4, 2, 3, 8, 2), PartPose.ZERO);
        robot.addOrReplaceChild("right_back_panel", CubeListBuilder.create().texOffs(96, 24).addBox(-8, -4, 2, 3, 8, 2), PartPose.ZERO);

        // Vehicle form: low sports-car chassis, sloped cabin, hood, bumpers, wheels and police lightbar.
        PartDefinition car = root.addOrReplaceChild("vehicle", CubeListBuilder.create(), PartPose.ZERO);
        car.addOrReplaceChild("chassis", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-9, -3, -13, 18, 5, 26)
                .texOffs(0, 64).addBox(-8, -4, -12, 16, 2, 9)
                .texOffs(0, 92).addBox(-8, -4, 5, 16, 2, 7), PartPose.offset(0, 7, 0));
        car.addOrReplaceChild("cabin", CubeListBuilder.create()
                .texOffs(0, 40).addBox(-6, -9, -5, 12, 5, 10)
                .texOffs(88, 40).addBox(-5, -10, -3, 10, 1, 6), PartPose.offset(0, 4, 0));
        car.addOrReplaceChild("hood", CubeListBuilder.create().texOffs(64, 64).addBox(-7, -4, -13, 14, 2, 7), PartPose.offset(0, 7, 0));
        car.addOrReplaceChild("front_bumper", CubeListBuilder.create().texOffs(0, 108).addBox(-9, 0, -14, 18, 2, 2), PartPose.offset(0, 7, 0));
        car.addOrReplaceChild("rear_bumper", CubeListBuilder.create().texOffs(0, 116).addBox(-9, 0, 12, 18, 2, 2), PartPose.offset(0, 7, 0));
        car.addOrReplaceChild("spoiler", CubeListBuilder.create().texOffs(72, 108).addBox(-7, -7, 10, 14, 1, 2), PartPose.offset(0, 4, 0));
        car.addOrReplaceChild("roof_lightbar", CubeListBuilder.create().texOffs(80, 116).addBox(-5, -7, -1, 10, 2, 2), PartPose.offset(0, 4, 0));
        // More convincing sports/patrol-car silhouette: windshield frame, grille, intake, mirrors and side doors.
        car.addOrReplaceChild("windshield", CubeListBuilder.create().texOffs(0, 40).addBox(-5.5F, -9.2F, -4.6F, 11, 4, 1), PartPose.offset(0, 4, 0));
        car.addOrReplaceChild("front_grille", CubeListBuilder.create().texOffs(0, 120).addBox(-4.5F, -1.4F, -14.3F, 9, 2, 1), PartPose.offset(0, 7, 0));
        car.addOrReplaceChild("hood_intake", CubeListBuilder.create().texOffs(68, 92).addBox(-3, -5.2F, -11, 6, 1, 3), PartPose.offset(0, 7, 0));
        car.addOrReplaceChild("mirror_l", CubeListBuilder.create().texOffs(108, 0).addBox(-8, -5, -5, 2, 2, 3), PartPose.offset(0, 4, 0));
        car.addOrReplaceChild("mirror_r", CubeListBuilder.create().texOffs(108, 0).addBox(6, -5, -5, 2, 2, 3), PartPose.offset(0, 4, 0));
        car.addOrReplaceChild("door_l", CubeListBuilder.create().texOffs(64, 84).addBox(-8.7F, -3, -3, 1, 5, 8), PartPose.offset(0, 4, 0));
        car.addOrReplaceChild("door_r", CubeListBuilder.create().texOffs(64, 84).addBox(7.7F, -3, -3, 1, 5, 8), PartPose.offset(0, 4, 0));
        car.addOrReplaceChild("rear_diffuser", CubeListBuilder.create().texOffs(0, 108).addBox(-6, 1, 12, 12, 2, 2), PartPose.offset(0, 7, 0));
        addWheel(car, "wheel_fl", -9, 8, -8);
        addWheel(car, "wheel_fr", 9, 8, -8);
        addWheel(car, "wheel_bl", -9, 8, 8);
        addWheel(car, "wheel_br", 9, 8, 8);
        car.addOrReplaceChild("light_left", CubeListBuilder.create().texOffs(104, 108).addBox(-7, -1, -14.2F, 4, 2, 1), PartPose.offset(0, 7, 0));
        car.addOrReplaceChild("light_right", CubeListBuilder.create().texOffs(104, 108).addBox(3, -1, -14.2F, 4, 2, 1), PartPose.offset(0, 7, 0));
        car.addOrReplaceChild("side_skirt_l", CubeListBuilder.create().texOffs(64, 84).addBox(-9.5F, 2, -5, 1, 2, 10), PartPose.offset(0, 4, 0));
        car.addOrReplaceChild("side_skirt_r", CubeListBuilder.create().texOffs(64, 84).addBox(8.5F, 2, -5, 1, 2, 10), PartPose.offset(0, 4, 0));
        car.addOrReplaceChild("hood_ridge_left", CubeListBuilder.create().texOffs(80, 112)
                .addBox(-5.6F, -5.0F, -12.0F, 1.0F, 1.0F, 7.5F), PartPose.offset(0, 7, 0));
        car.addOrReplaceChild("hood_ridge_right", CubeListBuilder.create().texOffs(80, 112)
                .addBox(4.6F, -5.0F, -12.0F, 1.0F, 1.0F, 7.5F), PartPose.offset(0, 7, 0));
        car.addOrReplaceChild("front_splitter", CubeListBuilder.create().texOffs(96, 112)
                .addBox(-8.5F, 1.1F, -14.7F, 17.0F, 0.8F, 1.5F), PartPose.offset(0, 7, 0));
        car.addOrReplaceChild("rear_exhaust_left", CubeListBuilder.create().texOffs(108, 112)
                .addBox(-6.5F, 1.1F, 13.0F, 2.0F, 1.0F, 1.0F), PartPose.offset(0, 7, 0));
        car.addOrReplaceChild("rear_exhaust_right", CubeListBuilder.create().texOffs(108, 112)
                .addBox(4.5F, 1.1F, 13.0F, 2.0F, 1.0F, 1.0F), PartPose.offset(0, 7, 0));
        car.addOrReplaceChild("rear_wing_supports", CubeListBuilder.create().texOffs(116, 112)
                .addBox(-5.8F, -5.6F, 10.5F, 0.8F, 2.0F, 0.8F)
                .addBox(5.0F, -5.6F, 10.5F, 0.8F, 2.0F, 0.8F), PartPose.offset(0, 4, 0));

        return LayerDefinition.create(mesh, 128, 128);
    }

    /** Builds a faceted, near-round tire from ten overlapping tread segments and a metal hub. */
    private static void addWheel(PartDefinition parent, String name, float x, float y, float z) {
        PartDefinition wheel = parent.addOrReplaceChild(name, CubeListBuilder.create(), PartPose.offset(x, y, z));
        for (int i = 0; i < 10; i++) {
            float angle = (float) (i * Math.PI * 2.0 / 10.0);
            float ringY = -3.15F * (float) Math.cos(angle);
            float ringZ =  3.15F * (float) Math.sin(angle);
            wheel.addOrReplaceChild("tread_" + i, CubeListBuilder.create()
                    .texOffs(96, 48).addBox(-2.8F, -1.35F, -0.95F, 5.6F, 2.7F, 1.9F),
                    PartPose.offsetAndRotation(0.0F, ringY, ringZ, angle + (float) Math.PI / 2.0F, 0.0F, 0.0F));
        }
        wheel.addOrReplaceChild("inner_rim", CubeListBuilder.create()
                .texOffs(108, 48).addBox(-2.9F, -2.1F, -2.1F, 5.8F, 4.2F, 4.2F), PartPose.ZERO);
        wheel.addOrReplaceChild("hub_cap", CubeListBuilder.create()
                .texOffs(116, 48).addBox(-3.05F, -1.15F, -1.15F, 6.1F, 2.3F, 2.3F), PartPose.ZERO);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float partial = ageInTicks - entity.tickCount;
        float carProgress = entity.getTransformationProgress(partial);
        boolean transforming = entity.isTransforming();
        robot.visible = carProgress < 0.995F || transforming;
        vehicle.visible = carProgress > 0.005F || transforming;

        // Scale cross-fade plus articulated folding: shoulders swing inward, arms fold, legs tuck.
        vehicleScale = Mth.clamp(carProgress * 1.12F, 0.001F, 1.12F);
        robotScale = Mth.clamp(1.0F - carProgress * 0.72F, 0.28F, 1.0F);
        robotFold = Mth.sin(carProgress * (float)Math.PI);
        robot.y = -robotFold * 3.0F;
        robot.xRot = robotFold * 0.18F;
        vehicle.y = (1.0F - carProgress) * 3.0F;
        vehicle.xRot = (1.0F - carProgress) * 0.12F;

        head.yRot = netHeadYaw * ((float)Math.PI / 180F) * (1.0F - carProgress);
        head.xRot = headPitch * ((float)Math.PI / 180F) * (1.0F - carProgress);
        float walk = Mth.cos(limbSwing * 0.6662F) * limbSwingAmount * 0.8F;
        leftArm.xRot = Mth.cos(limbSwing * 0.6662F + (float)Math.PI) * limbSwingAmount * 0.8F
                + robotFold * 1.15F;
        rightArm.xRot = Mth.cos(limbSwing * 0.6662F) * limbSwingAmount * 0.8F + robotFold * 1.15F;
        leftArm.zRot = robotFold * 0.85F;
        rightArm.zRot = -robotFold * 0.85F;
        leftLeg.xRot = walk + robotFold * 0.95F;
        rightLeg.xRot = -walk + robotFold * 0.95F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        if (robot.visible) {
            poseStack.pushPose();
            poseStack.scale(robotScale, robotScale, robotScale);
            robot.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            poseStack.popPose();
        }
        if (vehicle.visible) {
            poseStack.pushPose();
            poseStack.scale(vehicleScale, vehicleScale, vehicleScale);
            vehicle.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            poseStack.popPose();
        }
    }
}
