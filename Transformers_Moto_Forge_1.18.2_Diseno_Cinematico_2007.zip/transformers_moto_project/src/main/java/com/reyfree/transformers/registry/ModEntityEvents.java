package com.reyfree.transformers.registry;

import com.reyfree.transformers.TransformersMod;
import com.reyfree.transformers.entity.TransformerEntity;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TransformersMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEntityEvents {
    @SubscribeEvent
    public static void onAttributeCreate(EntityAttributeCreationEvent event) {
        event.put(ModEntities.TRANSFORMER.get(), TransformerEntity.createAttributes().build());
    }

    private ModEntityEvents() {}
}
