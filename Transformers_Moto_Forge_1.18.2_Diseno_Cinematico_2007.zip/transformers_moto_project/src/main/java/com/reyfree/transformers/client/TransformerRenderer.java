package com.reyfree.transformers.client;

import com.reyfree.transformers.TransformersMod;
import com.reyfree.transformers.entity.TransformerEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class TransformerRenderer extends MobRenderer<TransformerEntity, TransformerModel<TransformerEntity>> {
    private static final ResourceLocation BLUE_ROBOT = new ResourceLocation(TransformersMod.MODID, "textures/entity/blue_robot.png");
    private static final ResourceLocation BLUE_CAR = new ResourceLocation(TransformersMod.MODID, "textures/entity/blue_car.png");
    private static final ResourceLocation POLICE_ROBOT = new ResourceLocation(TransformersMod.MODID, "textures/entity/police_robot.png");
    private static final ResourceLocation POLICE_CAR = new ResourceLocation(TransformersMod.MODID, "textures/entity/police_car.png");

    public TransformerRenderer(EntityRendererProvider.Context context) {
        super(context, new TransformerModel<>(context.bakeLayer(TransformerModel.LAYER_LOCATION)), 0.65F);
    }

    @Override
    public ResourceLocation getTextureLocation(TransformerEntity entity) {
        if (entity.isPolice()) return entity.isVehicleMode() ? POLICE_CAR : POLICE_ROBOT;
        return entity.isVehicleMode() ? BLUE_CAR : BLUE_ROBOT;
    }
}
