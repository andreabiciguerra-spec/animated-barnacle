package com.reyfree.transformers.registry;

import com.reyfree.transformers.TransformersMod;
import com.reyfree.transformers.item.TransformerCoreItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, TransformersMod.MODID);

    public static final RegistryObject<Item> BLUE_CORE = ITEMS.register("blue_transformer_core",
            () -> new TransformerCoreItem(false, new Item.Properties().tab(CreativeModeTab.TAB_TOOLS).stacksTo(1)));
    public static final RegistryObject<Item> POLICE_CORE = ITEMS.register("police_transformer_core",
            () -> new TransformerCoreItem(true, new Item.Properties().tab(CreativeModeTab.TAB_TOOLS).stacksTo(1)));

    private ModItems() {}
}
