package com.reyfree.transformers.entity;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.network.chat.Component;

public class TransformerEntity extends PathfinderMob {
    private static final EntityDataAccessor<Boolean> VEHICLE_MODE =
            SynchedEntityData.defineId(TransformerEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> POLICE_VARIANT =
            SynchedEntityData.defineId(TransformerEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> TRANSFORM_TICKS =
            SynchedEntityData.defineId(TransformerEntity.class, EntityDataSerializers.INT);
    private static final int TRANSFORM_DURATION = 32;

    public TransformerEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.xpReward = 12;
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 90.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.30D)
                .add(Attributes.ATTACK_DAMAGE, 14.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.75D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(VEHICLE_MODE, false);
        this.entityData.define(POLICE_VARIANT, false);
        this.entityData.define(TRANSFORM_TICKS, TRANSFORM_DURATION);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15D, true));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Monster.class, true));
    }

    public boolean isVehicleMode() {
        return this.entityData.get(VEHICLE_MODE);
    }

    public void setVehicleMode(boolean vehicleMode) {
        if (this.isTransforming() || this.isVehicleMode() == vehicleMode) return;
        this.entityData.set(VEHICLE_MODE, vehicleMode);
        this.entityData.set(TRANSFORM_TICKS, 0);
        this.setDeltaMovement(Vec3.ZERO);
        this.getNavigation().stop();
    }

    public boolean isTransforming() {
        return this.entityData.get(TRANSFORM_TICKS) < TRANSFORM_DURATION;
    }

    /** 0 = robot, 1 = vehicle; smoothly interpolated during the 1.6 second transformation. */
    public float getTransformationProgress(float partialTick) {
        float t = Mth.clamp((this.entityData.get(TRANSFORM_TICKS) + partialTick) / (float) TRANSFORM_DURATION, 0.0F, 1.0F);
        return this.isVehicleMode() ? t : 1.0F - t;
    }

    @Override
    public void tick() {
        super.tick();
        int ticks = this.entityData.get(TRANSFORM_TICKS);
        if (ticks < TRANSFORM_DURATION) {
            ticks++;
            this.entityData.set(TRANSFORM_TICKS, ticks);
            if (ticks == TRANSFORM_DURATION) this.refreshDimensions();
        }
    }

    public boolean isPolice() {
        return this.entityData.get(POLICE_VARIANT);
    }

    public void setPolice(boolean police) {
        this.entityData.set(POLICE_VARIANT, police);
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        boolean finished = !this.isTransforming();
        return this.isVehicleMode() && finished ? EntityDimensions.scalable(2.55F, 1.12F)
                : EntityDimensions.scalable(1.45F, 2.35F);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (player.isShiftKeyDown()) {
            if (!this.level.isClientSide && !this.isTransforming()) {
                boolean toVehicle = !this.isVehicleMode();
                this.setVehicleMode(toVehicle);
                player.displayClientMessage(Component.literal(toVehicle
                        ? "¡Transformación a vehículo iniciada!" : "¡Transformación a robot iniciada!"), true);
            }
            return InteractionResult.sidedSuccess(this.level.isClientSide);
        }
        if (this.isVehicleMode() && !this.isTransforming() && !this.level.isClientSide && this.getPassengers().isEmpty()) {
            player.startRiding(this);
            return InteractionResult.CONSUME;
        }
        return InteractionResult.PASS;
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return this.isVehicleMode() && !this.isTransforming() && this.getPassengers().isEmpty() && passenger instanceof Player;
    }

    @Override
    public double getPassengersRidingOffset() {
        return this.isVehicleMode() && !this.isTransforming() ? 0.78D : super.getPassengersRidingOffset();
    }

    @Override
    public void travel(Vec3 travelVector) {
        if (this.isVehicleMode() && this.getControllingPassenger() instanceof Player rider) {
            this.setYRot(rider.getYRot());
            this.yRotO = this.getYRot();
            float forward = rider.zza;
            float strafe = rider.xxa;
            float yaw = this.getYRot() * ((float)Math.PI / 180.0F);
            float speed = 0.34F;
            double dx = (double)(strafe * Mth.cos(yaw) - forward * Mth.sin(yaw)) * speed;
            double dz = (double)(forward * Mth.cos(yaw) + strafe * Mth.sin(yaw)) * speed;
            this.setDeltaMovement(dx, this.getDeltaMovement().y, dz);
            this.move(MoverType.SELF, this.getDeltaMovement());
            this.setDeltaMovement(this.getDeltaMovement().scale(0.88D));
        } else {
            super.travel(travelVector);
        }
    }

    public Player getControllingPassenger() {
        Entity passenger = this.getFirstPassenger();
        return passenger instanceof Player ? (Player) passenger : null;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.IRON_GOLEM_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.IRON_GOLEM_DEATH;
    }
}
