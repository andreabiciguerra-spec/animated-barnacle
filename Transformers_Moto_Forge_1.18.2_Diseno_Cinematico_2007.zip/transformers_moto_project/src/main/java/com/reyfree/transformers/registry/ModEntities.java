package com.reyfree.transformers.registry;

import com.reyfree.transformers.TransformersMod;
import com.reyfree.transformers.entity.TransformerEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, TransformersMod.MODID);

    public static final RegistryObject<EntityType<TransformerEntity>> TRANSFORMER = ENTITY_TYPES.register(
            "transformer",
            () -> EntityType.Builder.<TransformerEntity>of(TransformerEntity::new, MobCategory.CREATURE)
                    .sized(1.35F, 2.25F)
                    .clientTrackingRange(10)
                    .build(TransformersMod.MODID + ":transformer")
    );

    private ModEntities() {}
}
