package com.reyfree.transformers;

import com.reyfree.transformers.registry.ModEntities;
import com.reyfree.transformers.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(TransformersMod.MODID)
public class TransformersMod {
    public static final String MODID = "transformers";

    public TransformersMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITY_TYPES.register(modBus);
        ModItems.ITEMS.register(modBus);
    }
}
