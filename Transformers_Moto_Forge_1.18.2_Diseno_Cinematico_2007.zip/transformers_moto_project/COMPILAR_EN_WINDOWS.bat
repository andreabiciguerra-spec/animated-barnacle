@echo off
chcp 65001 >nul
echo TRANSFORMERS - Compilador de proyecto
if exist gradlew.bat (
  call gradlew.bat build
) else (
  echo No se encontro gradlew.bat.
  echo Copia build.gradle, settings.gradle, gradle.properties y src dentro de una carpeta del MDK oficial de Forge 1.18.2-40.3.11.
  echo Luego ejecuta gradlew.bat build desde esa carpeta.
  pause
  exit /b 1
)
echo.
echo Si la compilacion fue correcta, revisa build\libs\transformers-1.0.0.jar
pause
